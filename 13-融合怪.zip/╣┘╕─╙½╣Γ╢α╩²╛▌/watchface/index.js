// 本表盘由酷安@丘绔君制作
try {
  (() => {
    var o = __$$hmAppManager$$__.currentApp,
      v = o.current;
    var N = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(o, v), "drink");

    console.log("-----\x3e>>current"),
      console.log(__$$hmAppManager$$__.currentApp.pid),
      console.log(__$$hmAppManager$$__.currentApp.current);

    // 载入素材
    let ten_array = [];
    let one_array = [];
    let d = [];
    let w = [];
    let datanum = [];
    let sf = [];
    let bf = [];
    for (let i = 0; i < 10; i++) {
      ten_array.push(`images/hour/${i}.png`);
      one_array.push(`images/minute/${i}.png`);
      d.push(`images/data/${i}.png`);
      datanum.push(`images/data/${i}.png`);
      sf.push(`images/greenfont/${i}.png`);
      bf.push(`images/editdata/${i}.png`);
    }
    for (let i = 1; i < 8; i++) {
      w.push(`images/week/${i}.png`);
    }

    // 横屏相关参数
    const jstime = hmSensor.createSensor(hmSensor.id.TIME);
    function setImgPath(widget, font, index) {
      widget.setProperty(hmUI.prop.SRC, font[index]);
    }
    function fnSetTime() {
      setImgPath(timehour1, ten_array, parseInt(jstime.format_hour / 10));
      setImgPath(timehour2, one_array, parseInt(jstime.format_hour % 10));
      setImgPath(timemin1, ten_array, parseInt(jstime.minute / 10));
      setImgPath(timemin2, one_array, parseInt(jstime.minute % 10));
      setImgPath(timesecond1, ten_array, parseInt(jstime.second / 10));
      setImgPath(timesecond2, one_array, parseInt(jstime.second % 10));
    }
    let timehour1 = {
      x: 80,
      y: 85,
      w: 60,
      h: 42,
      pos_x: 0,
      pos_y: 0,
      center_x: 60 / 2,
      center_y: 60 / 2,
      angle: 90,
      show_level: hmUI.show_level.ONAL_AOD,
    };
    let timehour2 = {
      x: 80,
      y: 135,
      w: 60,
      h: 42,
      pos_x: 0,
      pos_y: 0,
      center_x: 60 / 2,
      center_y: 60 / 2,
      angle: 90,
      show_level: hmUI.show_level.ONAL_AOD,
    };
    let timemin1 = {
      x: 80,
      y: 215,
      w: 60,
      h: 42,
      pos_x: 0,
      pos_y: 0,
      center_x: 60 / 2,
      center_y: 60 / 2,
      angle: 90,
      show_level: hmUI.show_level.ONAL_AOD,
    };
    let timemin2 = {
      x: 80,
      y: 265,
      w: 60,
      h: 42,
      pos_x: 0,
      pos_y: 0,
      center_x: 60 / 2,
      center_y: 60 / 2,
      angle: 90,
      show_level: hmUI.show_level.ONAL_AOD,
    };
    let timesecond1 = {
      x: 80,
      y: 345,
      w: 60,
      h: 42,
      pos_x: 0,
      pos_y: 0,
      center_x: 60 / 2,
      center_y: 60 / 2,
      angle: 90,
      show_level: hmUI.show_level.ONAL_AOD,
    };
    let timesecond2 = {
      x: 80,
      y: 395,
      w: 60,
      h: 42,
      pos_x: 0,
      pos_y: 0,
      center_x: 60 / 2,
      center_y: 60 / 2,
      angle: 90,
      show_level: hmUI.show_level.ONAL_AOD,
    };

    const L = DeviceRuntimeCore.HmLogger.getLogger("defult");
    v.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        // 背景
        let bg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "images/bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 时间
        let time_normal = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_space: -2,
          hour_zero: 1,
          hour_startX: 14,
          hour_startY: 106,
          hour_array: one_array,
          minute_space: -2,
          minute_zero: 1,
          minute_startX: 96,
          minute_startY: 106,
          minute_array: ten_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let time_aod = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_space: -2,
          hour_zero: 1,
          hour_startX: 14,
          hour_startY: 106,
          hour_array: one_array,
          minute_space: -2,
          minute_zero: 1,
          minute_startX: 96,
          minute_startY: 106,
          minute_array: ten_array,
          show_level: hmUI.show_level.ONAL_AOD,
        });
        // 星期
        let week_normal = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 17,
          y: 175,
          week_en: w,
          week_sc: w,
          week_tc: w,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let week_aod = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 17,
          y: 175,
          week_en: w,
          week_sc: w,
          week_tc: w,
          show_level: hmUI.show_level.ONAL_AOD,
        });
        // 日期
        let date_normal = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 85,
          month_startY: 179,
          month_zero: 1,
          month_space: 0,
          month_en_array: d,
          month_sc_array: d,
          month_tc_array: d,
          month_unit_sc: "images/data/point.png",
          month_unit_tc: "images/data/point.png",
          month_unit_en: "images/data/point.png",
          day_follow: true,
          day_zero: 1,
          day_space: 0,
          day_en_array: d,
          day_sc_array: d,
          day_tc_array: d,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        let date_aod = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 85,
          month_startY: 179,
          month_zero: 1,
          month_space: 0,
          month_en_array: d,
          month_sc_array: d,
          month_tc_array: d,
          month_unit_sc: "images/data/point.png",
          month_unit_tc: "images/data/point.png",
          month_unit_en: "images/data/point.png",
          day_follow: true,
          day_zero: 1,
          day_space: 0,
          day_en_array: d,
          day_sc_array: d,
          day_tc_array: d,
          show_level: hmUI.show_level.ONAL_AOD,
        });

        // 卡路里数据
        let cal = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 0,
          y: 215,
          w: 183,
          font_array: datanum,
          dont_path: "images/data/point.png",
          type: hmUI.data_type.CAL,
          align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 睡眠时间
        let tst = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 0,
          y: 256,
          w: 183,
          font_array: datanum,
          dont_path: "images/data/point.png",
          negative_image: "images/data/negative.png",
          unit_sc: "images/data/hour.png",
          type: hmUI.data_type.SLEEP,
          align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 当前温度
        let temp = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 0,
          y: 297,
          w: 183,
          font_array: datanum,
          dont_path: "images/data/point.png",
          negative_image: "images/data/negative.png",
          unit_sc: "images/data/degree.png",
          type: hmUI.data_type.WEATHER_CURRENT,
          align_h: hmUI.align.RIGHT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 步数圆弧背景
        let step_levelbg = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 96,
          center_y: 85,
          radius: 71,
          start_angle: -90,
          end_angle: 90,
          color: 0x1a404d15,
          line_width: 10,
          level: 100,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 步数数据圆弧
        let step_level = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 96,
          center_y: 85,
          radius: 71,
          start_angle: -90,
          end_angle: 90,
          color: 0xffd4ff46,
          line_width: 10,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 步数数字
        let stepnum = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 50,
          y: 63,
          w: 90,
          type: hmUI.data_type.STEP,
          font_array: sf,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 电池数字
        let batterynum = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 109,
          y: 383,
          w: 60,
          type: hmUI.data_type.BATTERY,
          font_array: bf,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 心率数字
        let heartnum = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 23,
          y: 383,
          w: 60,
          type: hmUI.data_type.HEART,
          font_array: bf,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 电池图标
        let lightup = hmUI.createWidget(hmUI.widget.IMG, {
          x: 101,
          y: 337,
          src: "images/editbg/battery.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 心率图标
        let lightdwn = hmUI.createWidget(hmUI.widget.IMG, {
          x: 15,
          y: 337,
          src: "images/editbg/heart.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 运动图标
        let sportlist = hmUI.createWidget(hmUI.widget.IMG, {
          x: 55,
          y: 405,
          src: "images/sporticon.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 勿扰点击区域
        let dndbtn = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 100,
          y: 105,
          w: 92,
          h: 60,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.CHAR_WRAP,
          text: " ",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // 震动反馈
        let vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        function hapticFeedback() {
          vibrate.stop();
          vibrate.scene = 23;
          vibrate.start();
        }
        // 跳转开关
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 0,
          y: 110,
          w: 192,
          h: 40,
          color: 0xffffff,
          text_size: 28,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.CHAR_WRAP,
          text: "跳转开关",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        let editGroup1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 001,
          x: 50,
          y: 160,
          w: 101,
          h: 48,
          select_image: "images/btn.png",
          un_select_image: "",
          default_type: hmUI.edit_type.HEART,
          optional_types: [
            { type: hmUI.edit_type.HEART, preview: "images/switch_on.png" },
            { type: hmUI.edit_type.STEP, preview: "images/switch_off.png" },
          ],
          count: 2,
          tips_BG: "images/tips.png",
          tips_x: 40,
          tips_y: 85,
          tips_width: 0,
          tips_margin: 0,
        });
        switch (editGroup1.getProperty(hmUI.prop.CURRENT_TYPE)) {
          case hmUI.edit_type.HEART:
            dndbtn.addEventListener(hmUI.event.CLICK_UP, function () {
              hapticFeedback();
              hmApp.startApp({ url: "Settings_dndModelScreen", native: true });
            });
            sportlist.addEventListener(hmUI.event.CLICK_UP, function () {
              hapticFeedback();
              hmApp.startApp({ url: "SportListScreen", native: true });
            });
            lightdwn.addEventListener(hmUI.event.CLICK_UP, function () {
              hapticFeedback();
              let r = hmSetting.getBrightness();
              r < 20 ? hmSetting.setBrightness(0) : hmSetting.setBrightness(Math.round(r / 20) * 20 - 20);
            });
            lightup.addEventListener(hmUI.event.CLICK_UP, function () {
              hapticFeedback();
              let r = hmSetting.getBrightness();
              r > 80 ? hmSetting.setBrightness(100) : hmSetting.setBrightness(Math.round(r / 20) * 20 + 20);
            });
            break;
          case hmUI.edit_type.STEP:
            break;
        }
        // 智慧横屏
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 0,
          y: 210,
          w: 192,
          h: 40,
          color: 0xffffff,
          text_size: 28,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.CHAR_WRAP,
          text: "智慧横屏",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        // ***************************
        timehour1 = hmUI.createWidget(hmUI.widget.IMG, timehour1);
        timehour2 = hmUI.createWidget(hmUI.widget.IMG, timehour2);
        timemin1 = hmUI.createWidget(hmUI.widget.IMG, timemin1);
        timemin2 = hmUI.createWidget(hmUI.widget.IMG, timemin2);
        timesecond1 = hmUI.createWidget(hmUI.widget.IMG, timesecond1);
        timesecond2 = hmUI.createWidget(hmUI.widget.IMG, timesecond2);
        // ***************************
        let editGroup2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 002,
          x: 50,
          y: 260,
          w: 101,
          h: 48,
          select_image: "images/btn.png",
          un_select_image: "",
          default_type: hmUI.edit_type.HEART,
          optional_types: [
            { type: hmUI.edit_type.HEART, preview: "images/switch_on.png" },
            { type: hmUI.edit_type.STEP, preview: "images/switch_off.png" },
          ],
          count: 2,
          tips_BG: "images/tips.png",
          tips_x: 40,
          tips_y: 85,
          tips_width: 0,
          tips_margin: 0,
        });
        let wear = hmSensor.createSensor(hmSensor.id.WEAR);
        let nowwear = wear.current;
        switch (editGroup2.getProperty(hmUI.prop.CURRENT_TYPE)) {
          case hmUI.edit_type.HEART:
            wear.addEventListener(hmSensor.event.CHANGE, function () {
              hmSetting.setBrightScreen(3);
            });
            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: function () {
                if (nowwear < 1) {
                  // 脱离手腕，横屏模式
                  time_aod.setProperty(hmUI.prop.VISIBLE, false);
                  week_aod.setProperty(hmUI.prop.VISIBLE, false);
                  date_aod.setProperty(hmUI.prop.VISIBLE, false);
                  // fnSetTime();
                  clock_timer = timer.createTimer(0, 1000, function (option) {
                    fnSetTime();
                  });
                } else {
                  // 戴在手腕，竖屏模式
                  hmUI.deleteWidget(timehour1);
                  hmUI.deleteWidget(timehour2);
                  hmUI.deleteWidget(timemin1);
                  hmUI.deleteWidget(timemin2);
                  hmUI.deleteWidget(timesecond1);
                  hmUI.deleteWidget(timesecond2);
                  time_normal.setProperty(hmUI.prop.VISIBLE, true);
                  week_normal.setProperty(hmUI.prop.VISIBLE, true);
                  date_normal.setProperty(hmUI.prop.VISIBLE, true);
                }
              },
            });
            break;
          case hmUI.edit_type.STEP:
            hmUI.deleteWidget(timehour1);
            hmUI.deleteWidget(timehour2);
            hmUI.deleteWidget(timemin1);
            hmUI.deleteWidget(timemin2);
            hmUI.deleteWidget(timesecond1);
            hmUI.deleteWidget(timesecond2);
            time_normal.setProperty(hmUI.prop.VISIBLE, true);
            week_normal.setProperty(hmUI.prop.VISIBLE, true);
            date_normal.setProperty(hmUI.prop.VISIBLE, true);
            break;
        }
        // 流畅模式
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 0,
          y: 310,
          w: 192,
          h: 40,
          color: 0xffffff,
          text_size: 28,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.CHAR_WRAP,
          text: "流畅模式",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        let editGroup3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 003,
          x: 50,
          y: 360,
          w: 101,
          h: 48,
          select_image: "images/btn.png",
          un_select_image: "",
          default_type: hmUI.edit_type.HEART,
          optional_types: [
            { type: hmUI.edit_type.HEART, preview: "images/switch_on.png" },
            { type: hmUI.edit_type.STEP, preview: "images/switch_off.png" },
          ],
          count: 2,
          tips_BG: "images/tips.png",
          tips_x: 40,
          tips_y: 85,
          tips_width: 0,
          tips_margin: 0,
        });
        switch (editGroup3.getProperty(hmUI.prop.CURRENT_TYPE)) {
          case hmUI.edit_type.HEART:
            hmUI.deleteWidget(bg);
            hmUI.deleteWidget(cal);
            hmUI.deleteWidget(tst);
            hmUI.deleteWidget(temp);
            hmUI.deleteWidget(step_level);
            hmUI.deleteWidget(step_levelbg);
            hmUI.deleteWidget(stepnum);
            lightup.setProperty(hmUI.prop.MORE, { y: 337 - 100 });
            lightdwn.setProperty(hmUI.prop.MORE, { y: 337 - 100 });
            heartnum.setProperty(hmUI.prop.MORE, {
              x: 23,
              y: 383 - 100,
              w: 60,
              type: hmUI.data_type.HEART,
              font_array: bf,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            batterynum.setProperty(hmUI.prop.MORE, {
              x: 109,
              y: 383 - 100,
              w: 60,
              type: hmUI.data_type.BATTERY,
              font_array: bf,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            sportlist.setProperty(hmUI.prop.MORE, { y: 405 - 100 });
            stepnum.setProperty(hmUI.prop.MORE, {
              x: 50,
              y: 430,
              w: 90,
              type: hmUI.data_type.STEP,
              font_array: sf,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            break;
          case hmUI.edit_type.STEP:
            break;
        }
        //信息声明
        var notebg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: "images/author.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        var note = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 10,
          y: 140,
          w: 170,
          h: 360,
          color: 0xffffff,
          text_size: 23,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.CHAR_WRAP,
          text: "woody\n(酷安@vvody)\n\n表盘版权归开发者所有",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        note.addEventListener(hmUI.event.CLICK_UP, function () {
          notebg.setProperty(hmUI.prop.VISIBLE, false);
          note.setProperty(hmUI.prop.VISIBLE, false);
        });
      },
      onInit() {
        console.log("index page.js on init invoke"), this.init_view();
      },
      onReady() {
        console.log("index page.js on ready invoke");
      },
      onShow() {
        console.log("index page.js on show invoke");
      },
      onHide() {
        console.log("index page.js on hide invoke");
      },
      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
  })();
} catch (e) {
  console.log(e);
}
