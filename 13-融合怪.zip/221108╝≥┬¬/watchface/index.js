// 本表盘由酷安@丘绔君制作
try {
  (() => {
    var o = __$$hmAppManager$$__.currentApp,
      v = o.current;
    var N = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(o, v), "drink");

    console.log("-----\x3e>>current"),
      console.log(__$$hmAppManager$$__.currentApp.pid),
      console.log(__$$hmAppManager$$__.currentApp.current);

    let ten_array = [];
    let one_array = [];
    let d = [];
    let w = [];
    let datanum = [];
    let sf = [];
    let bf = [];

    for (let i = 0; i < 10; i++) {
      ten_array.push(`images/hour/${i}.png`);
      one_array.push(`images/minute/${i}.png`);
      d.push(`images/data/${i}.png`);
      datanum.push(`images/data/${i}.png`);
      sf.push(`images/greenfont/${i}.png`);
      bf.push(`images/editdata/${i}.png`);
    }
    for (let i = 1; i < 8; i++) {
      w.push(`images/week/${i}.png`);
    }

    let bg = {
      x: 0,
      y: 0,
      src: "images/bg.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let battery_bg = {
      x: 101,
      y: 337,
      src: "images/editbg/battery.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let battery_font = {
      x: 0,
      y: 255,
      w: 192,
      type: hmUI.data_type.BATTERY,
      font_array: bf,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let heart_bg = {
      x: 15,
      y: 337,
      src: "images/editbg/heart.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let heart_font = {
      x: 23,
      y: 383,
      w: 60,
      type: hmUI.data_type.HEART,
      font_array: bf,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let step_font = {
      x: 50,
      y: 63,
      w: 90,
      type: hmUI.data_type.STEP,
      font_array: sf,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //步数圆弧背景
    let step_levelbg = {
      center_x: 96,
      center_y: 85,
      radius: 71,
      start_angle: -90,
      end_angle: 90,
      color: 0x1a404d15,
      line_width: 10,
      level: 100,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    //步数数据圆弧
    let step_level = {
      center_x: 96,
      center_y: 85,
      radius: 71,
      start_angle: -90,
      end_angle: 90,
      color: 0xffd4ff46,
      line_width: 10,
      type: hmUI.data_type.STEP,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    // 时间
    const jstime = hmSensor.createSensor(hmSensor.id.TIME);
    function setImgPath(widget, font, index) {
      widget.setProperty(hmUI.prop.SRC, font[index]);
    }
    function fnSetTime() {
      setImgPath(time_hour1, ten_array, parseInt(jstime.format_hour / 10));
      setImgPath(time_hour2, one_array, parseInt(jstime.format_hour % 10));
      setImgPath(time_min1, ten_array, parseInt(jstime.minute / 10));
      setImgPath(time_min2, one_array, parseInt(jstime.minute % 10));
    }
    let time_hour1 = {
      x: 14,
      y: 140,
      w: 42,
      h: 60,
      alpha: 255,
      angle: 0,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    let time_hour2 = {
      x: 54,
      y: 140,
      w: 42,
      h: 60,
      alpha: 255,
      angle: 0,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    let time_min1 = {
      x: 96,
      y: 140,
      w: 42,
      h: 60,
      alpha: 255,
      angle: 0,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    let time_min2 = {
      x: 136,
      y: 140,
      w: 42,
      h: 60,
      alpha: 255,
      angle: 0,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    // 星期
    let week = {
      x: 17,
      y: 210,
      week_en: w,
      week_sc: w,
      week_tc: w,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    // 日期
    let date = {
      month_startX: 85,
      month_startY: 214,
      month_zero: 0,
      month_space: 0,
      month_en_array: d,
      month_sc_array: d,
      month_tc_array: d,
      month_unit_sc: "images/data/point.png",
      month_unit_tc: "images/data/point.png",
      month_unit_en: "images/data/point.png",
      day_follow: true,
      day_zero: 1,
      day_space: 0,
      day_en_array: d,
      day_sc_array: d,
      day_tc_array: d,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    };
    // 数据栏
    let cal_f = {
      x: 0,
      y: 215,
      w: 183,
      font_array: datanum,
      dont_path: "images/data/point.png",
      type: hmUI.data_type.CAL,
      align_h: hmUI.align.RIGHT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let tst_f = {
      x: 0,
      y: 310,
      w: 192,
      font_array: datanum,
      dont_path: "images/data/point.png",
      negative_image: "images/data/negative.png",
      unit_sc: "images/data/hour.png",
      type: hmUI.data_type.SLEEP,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let temp_f = {
      x: 0,
      y: 360,
      w: 192,
      font_array: datanum,
      dont_path: "images/data/point.png",
      negative_image: "images/data/negative.png",
      unit_sc: "images/data/degree.png",
      type: hmUI.data_type.WEATHER_CURRENT,
      align_h: hmUI.align.CENTER_H,
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let sporticon = {
      x: 55,
      y: 405,
      src: "images/sporticon.png",
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    const L = DeviceRuntimeCore.HmLogger.getLogger("defult");
    v.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        // hmUI.createWidget(hmUI.widget.IMG, bg);
        time_hour1 = hmUI.createWidget(hmUI.widget.IMG, time_hour1);
        time_hour2 = hmUI.createWidget(hmUI.widget.IMG, time_hour2);
        time_min1 = hmUI.createWidget(hmUI.widget.IMG, time_min1);
        time_min2 = hmUI.createWidget(hmUI.widget.IMG, time_min2);
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            fnSetTime(),
              (clock_timer = timer.createTimer(0, 1000, function (option) {
                fnSetTime();
              }));
          },
        });
        hmUI.createWidget(hmUI.widget.IMG_WEEK, week);
        hmUI.createWidget(hmUI.widget.IMG_DATE, date);
        // hmUI.createWidget(hmUI.widget.TEXT_IMG, cal_f);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, tst_f);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, temp_f);
        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, step_levelbg);
        hmUI.createWidget(hmUI.widget.ARC_PROGRESS, step_level);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, step_font);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, battery_font);
        // hmUI.createWidget(hmUI.widget.TEXT_IMG, heart_font);
        // hmUI.createWidget(hmUI.widget.IMG, battery_bg).addEventListener(hmUI.event.CLICK_UP, function () {
        //   let r = hmSetting.getBrightness();
        //   r > 80 ? hmSetting.setBrightness(100) : hmSetting.setBrightness(Math.round(r / 20) * 20 + 20);
        // });
        // hmUI.createWidget(hmUI.widget.IMG, heart_bg).addEventListener(hmUI.event.CLICK_UP, function () {
        //   let r = hmSetting.getBrightness();
        //   r < 20 ? hmSetting.setBrightness(0) : hmSetting.setBrightness(Math.round(r / 20) * 20 - 20);
        // });
        // hmUI.createWidget(hmUI.widget.IMG, sporticon).addEventListener(hmUI.event.CLICK_UP, function () {
        //   hmApp.startApp({ url: "SportListScreen", native: !0 });
        // });
        // dndButton = hmUI
        //   .createWidget(hmUI.widget.TEXT, {
        //     x: 100,
        //     y: 105,
        //     w: 92,
        //     h: 60,
        //     color: 0xffffff,
        //     text_size: 23,
        //     align_h: hmUI.align.CENTER_H,
        //     align_v: hmUI.align.CENTER_V,
        //     text_style: hmUI.text_style.CHAR_WRAP,
        //     text: " ",
        //     show_level: hmUI.show_level.ONLY_NORMAL,
        //   })
        //   .addEventListener(hmUI.event.CLICK_UP, function () {
        //     hmApp.startApp({ url: "Settings_dndModelScreen", native: !0 });
        //   });
      },
      onInit() {
        console.log("index page.js on init invoke"), this.init_view();
      },
      onReady() {
        console.log("index page.js on ready invoke");
      },
      onShow() {
        console.log("index page.js on show invoke");
      },
      onHide() {
        console.log("index page.js on hide invoke");
      },
      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
  })();
} catch (e) {
  console.log(e);
}
